package com.example.collaborativeband.ui.aboutme;

import androidx.lifecycle.ViewModel;

public class AboutMeViewModel extends ViewModel {

    /*private MutableLiveData<String> mText;

    public NotificationsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is notifications fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }*/

}