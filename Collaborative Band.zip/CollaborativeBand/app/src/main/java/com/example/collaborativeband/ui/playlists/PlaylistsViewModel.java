package com.example.collaborativeband.ui.playlists;

import androidx.lifecycle.ViewModel;

public class PlaylistsViewModel extends ViewModel {

    /*private MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }*/

}